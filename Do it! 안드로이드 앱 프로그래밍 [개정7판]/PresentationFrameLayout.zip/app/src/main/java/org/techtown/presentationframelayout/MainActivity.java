package org.techtown.presentationframelayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    ImageView imageView2;
    ImageView imageView3;

    int imageIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);
    }

    public void onButton1Clicked(View v) { //버튼 클릭시 작동하는 함수
        changeImage();
    }

    public void changeImage() { // 사진 변경 담당 함수
        if(imageIndex == 0) { // 1번째 이미지출력 차례일경우
            imageView.setVisibility(View.VISIBLE); // 1번째 이미지를 보이게한다
            imageView2.setVisibility(View.INVISIBLE); // 2번째 이미지를 보이게않게한다
            imageView3.setVisibility(View.INVISIBLE); // 3번째 이미지를 보이게않게한다
            imageIndex += 1; // 다음 이미지출력 차례로 이동
        } else if(imageIndex == 1) {
            imageView.setVisibility(View.INVISIBLE); // 1번째 이미지를 보이게않게한다
            imageView2.setVisibility(View.VISIBLE); // 2번째 이미지를 보이게한다
            imageView3.setVisibility(View.INVISIBLE); // 3번째 이미지를 보이게않게한다
            imageIndex += 1; // 다음 이미지출력 차례로 이동
        } else {
            imageView.setVisibility(View.INVISIBLE); // 1번째 이미지를 보이게않게한다
            imageView2.setVisibility(View.INVISIBLE); // 2번째 이미지를 보이게않게한다
            imageView3.setVisibility(View.VISIBLE); // 3번째 이미지를 보이게한다
            imageIndex = 0; // 첫 이미지출력 차례로 되돌아감
        }
    }

}