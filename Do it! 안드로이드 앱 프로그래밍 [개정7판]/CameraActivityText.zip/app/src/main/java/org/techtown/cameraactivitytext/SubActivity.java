package org.techtown.cameraactivitytext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    private TextView box_output_text1;
    private TextView box_output_text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);


//        byte[] byteArray = getIntent().getByteArrayExtra("image1");
//        Bitmap image = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
//
//        ImageView output_camera1 = findViewById(R.id.imageview_camera1);
//        output_camera1.setImageBitmap(image);

//        Bundle extras = getIntent().getExtras();
//        byte[] byteArray = getIntent().getByteArrayExtra("Camera1");
//        int exifDegree1 = extras.getInt("exifDegree1");
//        Log.d("byteArray 값", "값은:"+byteArray);
//        Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
//
//        ((ImageView) findViewById(R.id.imageview_camera1)).setImageBitmap(bitmap);

        //Bundle extras = getIntent().getExtras();
        //getIntent().getParcelableExtra("PhotoUri1");
        Uri Camera1PhotoUri1 = getIntent().getParcelableExtra("PhotoUri1");
        Uri Camera1PhotoUri2 = getIntent().getParcelableExtra("PhotoUri2");
        //Log.d("서브 Camera1PhotoUri 값", "은:"+Camera1PhotoUri1);

        ((ImageView) findViewById(R.id.imageview_camera1)).setImageURI(Camera1PhotoUri1);
        ((ImageView) findViewById(R.id.imageview_camera2)).setImageURI(Camera1PhotoUri2);



        box_output_text1 = findViewById(R.id.box_output_text1);
        box_output_text2 = findViewById(R.id.box_output_text2);

        Intent intent = getIntent(); // 다른 액티비티에서 보내진 값을 받아옴
        String str_text1 = intent.getStringExtra("str_input_text1"); // 텍스트입력칸1의 입력값 저장
        String str_text2 = intent.getStringExtra("str_input_text2"); // 텍스트입력칸2의 입력값 저장

        box_output_text1.setText(str_text1);
        box_output_text2.setText(str_text2);
    }

    private Bitmap rotate(Bitmap bitmap, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }
}