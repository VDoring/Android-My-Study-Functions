package org.techtown.fragment2;

public interface ImageSelectionCallback {

    public void onImageSelected(int position);

}
