// 참고한 영상 : https://www.youtube.com/watch?v=EKCQ6sxMWNo, https://www.youtube.com/watch?v=MAB8LEfRIG8 //

package org.techtown.cameraactivitytext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button button_move_subactivity;
    private EditText box_input_text1;
    private EditText box_input_text2;
    private String str_input_text1;
    private String str_input_text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        box_input_text1 = findViewById(R.id.box_input_text1); // 텍스트입력칸1 선언
        box_input_text2 = findViewById(R.id.box_input_text2); // 텍스트입력칸2 선언

        button_move_subactivity = findViewById(R.id.button_move_subactivity); // 서브액티비티로 가는 버튼 id 가져오기. id를 통해 레이아웃과 연결.
        button_move_subactivity.setOnClickListener(new View.OnClickListener() { // 버튼을 누를경우
            @Override
            public void onClick(View view) {
                str_input_text1 = box_input_text1.getText().toString(); // 텍스트입력칸1 입력값 저장
                str_input_text2 = box_input_text2.getText().toString(); // // 텍스트입력칸2 입력값 저장
                Intent intent = new Intent(MainActivity.this, SubActivity.class); // Intent()에 현재 액티비티, 이동하고 싶은 액티비티 입력
                intent.putExtra("str_input_text1", str_input_text1); // 다른 액티비티에 값을 넘기기 위한 과정. putExtra()에는 넣을 값의 별명, 넣을 값이 들어감
                intent.putExtra("str_input_text2", str_input_text2); // 다른 액티비티에 값을 넘기기 위한 과정. putExtra()에는 넣을 값의 별명, 넣을 값이 들어감

                startActivity(intent); // 액티비티 이동
            }
        });


    }
}