package org.techtown.cameraactivitytext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    private TextView box_output_text1;
    private TextView box_output_text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        box_output_text1 = findViewById(R.id.box_output_text1);
        box_output_text2 = findViewById(R.id.box_output_text2);

        Intent intent = getIntent(); // 다른 액티비티에서 보내진 값을 받아옴
        String str_text1 = intent.getStringExtra("str_input_text1"); // 텍스트입력칸1의 입력값 저장
        String str_text2 = intent.getStringExtra("str_input_text2"); // 텍스트입력칸2의 입력값 저장

        box_output_text1.setText(str_text1);
        box_output_text2.setText(str_text2);
    }
}