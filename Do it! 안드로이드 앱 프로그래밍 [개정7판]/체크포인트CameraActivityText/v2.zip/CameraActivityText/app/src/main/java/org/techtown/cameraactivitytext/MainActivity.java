// 참고한 영상 : https://www.youtube.com/watch?v=EKCQ6sxMWNo, https://www.youtube.com/watch?v=MAB8LEfRIG8 //

package org.techtown.cameraactivitytext;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE1 = 672;
    private static final int REQUEST_IMAGE_CAPTURE2 = 673;
    private String imageFilePath;
    private Uri photoUri;

    //// 텍스트 값 넘기기 부분 ////
    private Button button_move_subactivity;
    private EditText box_input_text1;
    private EditText box_input_text2;
    private String str_input_text1;
    private String str_input_text2;
    //// 텍스트 값 넘기기 부분 ////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 권한 체크
        TedPermission.with(getApplicationContext())
                .setPermissionListener(permissionListener)
                .setRationaleMessage("카메라 권한이 필요합니다.")
                .setDeniedMessage("거부하셨습니다.")
                .setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();

        findViewById(R.id.button_camera1).setOnClickListener(new View.OnClickListener() { // 촬영1 버튼 누를시
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); // 카메라 촬영 앱을 띄움
                if(intent.resolveActivity(getPackageManager()) != null) {
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                    } catch (IOException e) {

                    }

                    if(photoFile != null) {
                        photoUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName(), photoFile);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri); // 카메라 띄움
                        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE1); // 카메라 갔다올때 값을 넘겨받음
                    }
                }

            }
        });

        findViewById(R.id.button_camera2).setOnClickListener(new View.OnClickListener() { // 촬영2 버튼 누를시
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); // 카메라 촬영 앱을 띄움
                if(intent.resolveActivity(getPackageManager()) != null) {
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                    } catch (IOException e) {

                    }

                    if(photoFile != null) {
                        photoUri = FileProvider.getUriForFile(getApplicationContext(), getPackageName(), photoFile);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri); // 카메라 띄움
                        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE2); // 카메라 갔다올때 값을 넘겨받음
                    }
                }
            }
        });

        //// 텍스트 값 넘기기 부분 ////
        box_input_text1 = findViewById(R.id.box_input_text1); // 텍스트입력칸1 선언
        box_input_text2 = findViewById(R.id.box_input_text2); // 텍스트입력칸2 선언

        button_move_subactivity = findViewById(R.id.button_move_subactivity); // 서브액티비티로 가는 버튼 id 가져오기. id를 통해 레이아웃과 연결.
        button_move_subactivity.setOnClickListener(new View.OnClickListener() { // 버튼을 누를경우
            @Override
            public void onClick(View view) {
                str_input_text1 = box_input_text1.getText().toString(); // 텍스트입력칸1 입력값 저장
                str_input_text2 = box_input_text2.getText().toString(); // // 텍스트입력칸2 입력값 저장
                Intent intent = new Intent(MainActivity.this, SubActivity.class); // Intent()에 현재 액티비티, 이동하고 싶은 액티비티 입력
                intent.putExtra("str_input_text1", str_input_text1); // 다른 액티비티에 값을 넘기기 위한 과정. putExtra()에는 넣을 값의 별명, 넣을 값이 들어감
                intent.putExtra("str_input_text2", str_input_text2); // 다른 액티비티에 값을 넘기기 위한 과정. putExtra()에는 넣을 값의 별명, 넣을 값이 들어감

                startActivity(intent); // 액티비티 이동
            }
        });
        //// 텍스트 값 넘기기 부분 ////


    }

    private File createImageFile() throws IOException{
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()); // 이미지 파일 이름
        String imageFileName = "TEST" + timeStamp + " ";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        imageFilePath = image.getAbsolutePath();
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE1 && resultCode == RESULT_OK) {
            Bitmap bitmap = BitmapFactory.decodeFile(imageFilePath);
            ExifInterface exif = null;

            try {
                exif = new ExifInterface(imageFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            int exifOrientation;
            int exifDegree;

            if (exif != null) {
                exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                exifDegree = exifOrientationToDegress(exifOrientation);
            } else {
                exifDegree = 0;
            }

            // 이미지 표시하는 코드 //
            ((ImageView) findViewById(R.id.tempCamera1)).setImageBitmap(rotate(bitmap, exifDegree));

            // 이미지 데이터를 SubActivity로 전송하는 코드 //
            //Intent intent = new Intent(MainActivity.this, SubActivity.class);
            //ByteArrayOutputStream stream = new ByteArrayOutputStream();
            //bitmap.compress(Bitmap.CompressFormat.JPEG, 50, stream);
            //byte[] byteArray = stream.toByteArray();
            //intent.putExtra("image1", byteArray);
            //startActivity(intent);
        }

        if (requestCode == REQUEST_IMAGE_CAPTURE2 && resultCode == RESULT_OK) {
            Bitmap bitmap = BitmapFactory.decodeFile(imageFilePath);
            ExifInterface exif = null;

            try {
                exif = new ExifInterface(imageFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            int exifOrientation;
            int exifDegree;

            if (exif != null) {
                exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                exifDegree = exifOrientationToDegress(exifOrientation);
            } else {
                exifDegree = 0;
            }

            // 이미지 표시하는 코드 //
            ((ImageView) findViewById(R.id.tempCamera2)).setImageBitmap(rotate(bitmap, exifDegree));
        }

    }

    private Bitmap rotate(Bitmap bitmap, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private int exifOrientationToDegress(int exifOrientation) {
        if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
            return 90;
        } else if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
            return 180;
        } else if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
            return 270;
        }
        return 0;
    }

    PermissionListener permissionListener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
            Toast.makeText(getApplicationContext(), "권한이 허용되었습니다", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(getApplicationContext(), "권한이 거부되었습니다.", Toast.LENGTH_SHORT).show();
        }
    };


}