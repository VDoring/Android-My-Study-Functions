package org.vdoring.sqlitetest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // 디자인 변수 선언
    Button btn_data_add;
    Button btn_data_output;

    EditText edit_name;
    EditText edit_age;
    EditText edit_introduce;

    TextView view_data;

    // DBHelper
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 디자인 매핑
        setContentView(R.layout.activity_main);

        // Control 매핑
        edit_name = (EditText) findViewById(R.id.input_name);
        edit_age = (EditText) findViewById(R.id.input_age);
        edit_introduce = (EditText) findViewById(R.id.input_introduce);

        btn_data_add = (Button) findViewById(R.id.btn_data_add);
        btn_data_output = (Button) findViewById(R.id.btn_data_output);

        view_data = (TextView) findViewById(R.id.text_output);

        // 버튼 클릭 이벤트 정의
        btn_data_add.setOnClickListener(this);
        btn_data_output.setOnClickListener(this);

        dbHelper = new DBHelper(MainActivity.this, 1);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_data_add:
                dbHelper.insert(edit_name.getText().toString(), Integer.parseInt(edit_age.getText().toString()), edit_introduce.getText().toString());
                break;
            case R.id.btn_data_output:
                view_data.setText(dbHelper.getResult());
                break;
        }
    }
}



//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        DBHelper helper;
//        SQLiteDatabase db;
//        helper = new DBHelper(MainActivity.this, "testdatabase.db", null, 1);
//        db = helper.getWritableDatabase();
//        helper.onCreate(db);
//    }
//}
//
///*
//testdatabase라는 database에 mytable이라는 table을 생성하고, 수정가능하게 db를 불러옵니다.
//
//이렇게 하면 db 생성은 끝입니다.
//*/