package org.vdoring.imagefilters;
// https://www.youtube.com/watch?v=1MkiM9i-S5w

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.zomato.photofilters.SampleFilters;
import com.zomato.photofilters.imageprocessors.Filter;
import com.zomato.photofilters.imageprocessors.subfilters.BrightnessSubFilter;
import com.zomato.photofilters.imageprocessors.subfilters.ContrastSubFilter;
import com.zomato.photofilters.imageprocessors.subfilters.SaturationSubFilter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    static
    {
        System.loadLibrary("NativeImageProcessor");
    }

    ImageView imageView, filter1, filter2, filter3;
    Bitmap originalBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView) findViewById(R.id.image_view);
        filter1 = (ImageView) findViewById(R.id.filter1);
        filter2 = (ImageView) findViewById(R.id.filter2);
        filter3 = (ImageView) findViewById(R.id.filter3);

        filter1.setOnClickListener(this);
        filter2.setOnClickListener(this);
        filter3.setOnClickListener(this);

        BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
        originalBitmap = drawable.getBitmap();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.filter1:
                Filter sampleFilter1 = new Filter();
                sampleFilter1.addSubFilter(new BrightnessSubFilter(30));
                sampleFilter1.addSubFilter(new ContrastSubFilter(1.1f));
                //sampleFilter1.addSubFilter(new SaturationSubFilter(1.3f));
                Bitmap image1 = originalBitmap.copy(Bitmap.Config.ARGB_8888, true);
                Bitmap outputImage1= sampleFilter1.processFilter(image1);
                imageView.setImageBitmap(outputImage1);
                break;
            case R.id.filter2:
                Filter sampleFilter2 = SampleFilters.getBlueMessFilter();
                Bitmap image2 = originalBitmap.copy(Bitmap.Config.ARGB_8888, true);
                Bitmap outputImage2 = sampleFilter2.processFilter(image2);
                imageView.setImageBitmap(outputImage2);
                break;

            case R.id.filter3:
                Filter sampleFilter3 = SampleFilters.getLimeStutterFilter();
                Bitmap image3 = originalBitmap.copy(Bitmap.Config.ARGB_8888, true);
                Bitmap outputImage3 = sampleFilter3.processFilter(image3);
                imageView.setImageBitmap(outputImage3);
                break;
        }
    }
}