package org.vdoring.adapterviewtestmake;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by Administrator on 2016-04-25.
 */
public class CustomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom);

        ImageView img = (ImageView)findViewById(R.id.img);
        TextView title = (TextView)findViewById(R.id.txtTitle);
        TextView content = (TextView)findViewById(R.id.txtContent);
        Button btn = (Button)findViewById(R.id.close);

        Intent intent = getIntent();
        int id = intent.getExtras().getInt("POSITION");

        CustomDTO dto = MainActivity.list.get(id);

        img.setImageResource(dto.getImgIcon());
        title.setText(dto.getTitle());
        content.setText(dto.getContent());

        btn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}