package org.vdoring.adapterviewtestmake;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {

    Context ctxt;
    int layout;
    ArrayList<CustomDTO> list;
    LayoutInflater inf; // xml 레이아웃 문서의 자원(위젯)을 받아 객체 생성

    public CustomAdapter(Context ctxt, int layout, ArrayList<CustomDTO> list) {
        this.ctxt = ctxt;
        this.layout = layout;
        this.list = list;
        inf = (LayoutInflater)ctxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    // ListView에서 보여줘야 할 데이터 개수 지정 (ArrayList 크기로 지정)
    @Override
    public int getCount() {
        return list.size();
    }

    // ListView에서 보여줄 객체 지정
    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    // getItem() 메서드가 리턴한 객체의 고유 식별자
    @Override
    public long getItemId(int position) {
        return position;
    }

    // ListView에 실제로 행을 보여줄 때 호출되는 메서드
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {
            convertView = inf.inflate(layout, null);
        } // Layout.xml 자원을 대상으로 View 객체 생성

        // LayoutInflater 객체를 이용하여 Layout.xml 파일에서 id값을 가져오기
        TextView txtTitle = (TextView)convertView.findViewById(R.id.txtTitle);
        TextView txtContent = (TextView)convertView.findViewById(R.id.txtContent);
        ImageView imgView = (ImageView)convertView.findViewById(R.id.imgIcon);

        // 리스트에서 저장된 데이터를 순서대로 가져와서 DTO 클래스 타입 변수에 저장
        CustomDTO dto = list.get(position); // position에 해당하는 레코드 가져오기
        txtTitle.setText(dto.getTitle());
        txtContent.setText(dto.getContent());
        imgView.setImageResource(dto.getImgIcon());

        return convertView;
    }
}
