package org.vdoring.adapterviewtestmake;

public class CustomDTO {
    String title; // AdapterView에서 사용될 데이터
    String content;
    int imgIcon; // R.java에서 사용될 ID 상수

    public CustomDTO(String title, String content, int imgIcon) {
        this.title = title;
        this.content = content;
        this.imgIcon = imgIcon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getImgIcon() {
        return imgIcon;
    }

    public void setImgIcon(int imgIcon) {

        this.imgIcon = imgIcon;

    }

    @Override
    public String toString() {
        return "제목 : "+title+"내용 : "+content;
    }
}
