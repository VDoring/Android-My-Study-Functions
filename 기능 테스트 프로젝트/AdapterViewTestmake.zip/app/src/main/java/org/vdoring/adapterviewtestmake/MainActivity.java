package org.vdoring.adapterviewtestmake;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    public static ArrayList<CustomDTO> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = new ArrayList<CustomDTO>();
        list.add(new CustomDTO("어촌1", "바다가 굿!", R.drawable.ic_launcher_background));
        list.add(new CustomDTO("어촌2", "해변가 굿!", R.drawable.ic_launcher_background));
        list.add(new CustomDTO("산촌1", "산 고갯길 굿!", R.drawable.ic_launcher_background));
        list.add(new CustomDTO("산촌2", "산 마루길 굿!", R.drawable.ic_launcher_background));
        list.add(new CustomDTO("농촌1", "강변 굿!", R.drawable.ic_launcher_background));
        list.add(new CustomDTO("농촌2", "한옥 굿!", R.drawable.ic_launcher_background));

        listView = (ListView)findViewById(R.id.ListView02);

        // list 원소를 list_item 형식에 적용하여 어뎁터 뷰 생성
        CustomAdapter adapter =
                new CustomAdapter(getApplicationContext(), R.layout.list_item, list);

        listView.setAdapter(adapter);// 리스트 뷰에 적용

        // 이벤트 처리
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                /*Toast.makeText(getApplicationContext(),
                                parent.getItemAtPosition(position).toString(),
                                Toast.LENGTH_LONG).show();*/
                Intent intent =
                        new Intent(MainActivity.this, CustomActivity.class);
                intent.putExtra("POSITION", position);
                startActivity(intent);
            }
        });
    }
}