// https://www.youtube.com/watch?v=u2pgSu9RhYo
package org.vdoring.qrcodescanner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends AppCompatActivity {
    Button bt_scan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_scan = findViewById(R.id.bt_scan);

        bt_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // zxing 사용을 위해 Intent integrator 설정
                IntentIntegrator intentIntegrator = new IntentIntegrator(MainActivity.this);

                // QR코드 스캔 화면에서 출력할 메세지
                intentIntegrator.setPrompt("플래시를 조작하려면 볼륨 버튼을 누르세요.");
                // 비프음 출력 여부
                intentIntegrator.setBeepEnabled(true);
                // 방향 고정 여부
                intentIntegrator.setOrientationLocked(true);
                // 사용할 Activity 클래스 설정
                intentIntegrator.setCaptureActivity(Capture.class);
                // QR코드 스캔 시작
                intentIntegrator.initiateScan();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // QR코드 스캔 결과 및 데이터 저장
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(intentResult.getContents() != null) { // 만약 QR코드 주소가 나올경우
            // 작은 알림 창 설정
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            // 알림 창 제목
            builder.setTitle("Result");
            // 알림 창 내용
            builder.setMessage(intentResult.getContents());
            // 알림 창 확인 버튼 설정
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // 알림 창 종료
                    dialogInterface.dismiss();
                }
            });
            // 알림 창 출력
            builder.show();
        }
        else { // 만약 QR코드 주소가 안나올경우
            Toast.makeText(getApplicationContext(), "Link Not Found.", Toast.LENGTH_SHORT).show();
        }
    }
}