package org.vdoring.imagedynamichorizonscroll;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class SubLayout extends LinearLayout {

    public SubLayout(Context context, AttributeSet attrs, SampleItem sampleItem) {
        super(context, attrs);
        init(context, sampleItem);
    }

    public SubLayout(Context context, SampleItem sampleItem) {
        super(context);
        init(context, sampleItem);
    }

    private void init(Context context, SampleItem sampleItem) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.layout_sub_layout, this, true);

        ImageView img = (ImageView)findViewById(R.id.glide_imageview);
        TextView tvName = (TextView)findViewById(R.id.tv_name);
        TextView tvPrice = (TextView)findViewById(R.id.tv_price);

        // 이미지 로드 라이브러리 사용 ImageUrl to Image
        System.out.println("uri 확인:");
        System.out.println(sampleItem.getImageUrl());
        Glide.with(this)
                .load(sampleItem.getImageUrl())
                .override(300,300)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(img);
        tvName.setText(sampleItem.getName());
        tvPrice.setText(sampleItem.getPrice());
    }
}