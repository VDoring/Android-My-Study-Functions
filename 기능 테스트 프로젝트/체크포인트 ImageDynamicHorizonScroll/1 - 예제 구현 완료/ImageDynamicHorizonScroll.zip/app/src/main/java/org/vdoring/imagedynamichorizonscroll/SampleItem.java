package org.vdoring.imagedynamichorizonscroll;

public class SampleItem {
    String name;
    String price;
    String imageUrl;

    SampleItem(String name, String price, String imageUrl) {
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
    }
    public String getImageUrl() {
        return imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }
}