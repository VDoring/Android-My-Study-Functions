// https://dev-huhu.tistory.com/22

package org.vdoring.imagedynamichorizonscroll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<SampleItem> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arrayList = new ArrayList<>();
        SampleItem sampleItem = new SampleItem("aa", "1000원","https://cdn.pixabay.com/photo/2018/01/10/23/53/rabbit-3075088_1280.png");

        arrayList.add(sampleItem);
        arrayList.add(sampleItem);
        arrayList.add(sampleItem);
        arrayList.add(sampleItem);
        arrayList.add(sampleItem);
        arrayList.add(sampleItem);
        arrayList.add(sampleItem);

        for (int i = 0; i < arrayList.size(); i++){
            // 추가할 레이아웃
            SubLayout subLayout = new SubLayout(getApplicationContext(), arrayList.get(i));
            // 추가될 위치
            LinearLayout layout = (LinearLayout)findViewById(R.id.input_here_layout);
            layout.addView(subLayout);
        }

    }
}