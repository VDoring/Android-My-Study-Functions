package org.vdoring.imagedynamichorizonscroll;

public class SampleItem {
    String cnt;
    String imageUrl;

    SampleItem(String cnt, String imageUrl) {
        this.cnt = cnt+"번째 사진";
        this.imageUrl = imageUrl;
    }
    public String getImageUrl() {
        return imageUrl;
    }

    public String getNum() {
        return cnt;
    }
}