package org.vdoring.imagedynamichorizonscroll;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class SubLayout extends LinearLayout {

//    public SubLayout(Context context, AttributeSet attrs, SampleItem sampleItem) {
//        super(context, attrs);
//        init(context, sampleItem);
//    }

    public SubLayout(Context context, SampleItem sampleItem) {
        super(context);
        init(context, sampleItem);
    }

    private void init(Context context, SampleItem sampleItem) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.layout_sub_layout, this, true);

        ImageView glide_imageview = (ImageView)findViewById(R.id.glide_imageview);
        TextView tv_image_num = (TextView)findViewById(R.id.tv_image_num);

        // 이미지 로드 라이브러리 사용 ImageUrl to Image
        Glide.with(this)
                .load(sampleItem.getImageUrl())
                .override(350,350)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(glide_imageview);

        tv_image_num.setText(sampleItem.getNum());
    }
}