// https://dev-huhu.tistory.com/22

package org.vdoring.imagedynamichorizonscroll;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btn_add_image;
    ArrayList<SampleItem> imageList;
    Uri uri;

    int REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_add_image = findViewById(R.id.btn_add_image);

        imageList = new ArrayList<>();

        if(imageList.size() <= 0) {
            // "등록된 사진이 없습니다." 표시하기
        }
        else {
            for (int i = 0; i < imageList.size(); i++) {
                // 추가할 레이아웃
                SubLayout subLayout = new SubLayout(getApplicationContext(), imageList.get(i));
                // 추가될 위치
                LinearLayout layout = (LinearLayout) findViewById(R.id.input_here_layout);
                layout.addView(subLayout);
            }
        }

        btn_add_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentPicture = new Intent();
                intentPicture.setType("image/*");
                intentPicture.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(intentPicture, REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            uri = data.getData();

            SampleItem sampleItem = new SampleItem(String.valueOf(imageList.size()+1), uri.toString());
            imageList.add(sampleItem);

            // 추가할 레이아웃
            SubLayout subLayout = new SubLayout(getApplicationContext(), imageList.get(imageList.size()-1));
            // 추가될 위치
            LinearLayout layout = (LinearLayout)findViewById(R.id.input_here_layout);
            layout.addView(subLayout);
        }
    }
}