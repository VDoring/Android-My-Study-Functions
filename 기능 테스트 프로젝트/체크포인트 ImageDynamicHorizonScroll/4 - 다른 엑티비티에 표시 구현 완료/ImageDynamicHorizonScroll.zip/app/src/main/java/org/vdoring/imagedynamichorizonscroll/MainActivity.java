// https://dev-huhu.tistory.com/22

package org.vdoring.imagedynamichorizonscroll;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btn_add_image;
    ArrayList<Serializable> imageList;
    ArrayList<String> uriList;
    Uri uri;

    int REQUEST_CODE = 1;

    Button btn_next_activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_add_image = findViewById(R.id.btn_add_image);

        imageList = new ArrayList<>();
        uriList = new ArrayList<>();

        if(imageList.size() <= 0) {
            // "등록된 사진이 없습니다." 표시하기
        }
        else {
            for (int i = 0; i < imageList.size(); i++) {
                // 추가할 레이아웃
                SubLayout subLayout = new SubLayout(getApplicationContext(), imageList.get(i));
                // 추가될 위치
                LinearLayout layout = (LinearLayout) findViewById(R.id.input_here_layout);
                layout.addView(subLayout);
            }
        }

        btn_add_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentPicture = new Intent();
                intentPicture.setType("image/*");
                intentPicture.setAction(Intent.ACTION_GET_CONTENT);

                startActivityForResult(intentPicture, REQUEST_CODE);
            }
        });

        btn_next_activity = findViewById(R.id.btn_next_activity);
        btn_next_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(MainActivity.this, MainActivity2.class);
                intent2.putExtra("imageList", imageList);
                intent2.putStringArrayListExtra("uriList", uriList);
                startActivity(intent2);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            uri = data.getData();

            Serializable serializable = new Serializable(uri.toString());
            imageList.add(serializable);
            uriList.add(uri.toString());

            // 추가할 레이아웃
            SubLayout subLayout = new SubLayout(getApplicationContext(), imageList.get(imageList.size()-1));
            // 추가될 위치
            LinearLayout layout = (LinearLayout)findViewById(R.id.input_here_layout);
            layout.addView(subLayout);
        }
    }
}