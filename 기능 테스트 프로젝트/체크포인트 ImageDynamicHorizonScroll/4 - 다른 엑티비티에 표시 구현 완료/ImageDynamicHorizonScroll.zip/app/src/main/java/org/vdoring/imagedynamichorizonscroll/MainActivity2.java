package org.vdoring.imagedynamichorizonscroll;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    ArrayList<Serializable> imageList;
    ArrayList<String> uriList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        imageList = (ArrayList<Serializable>)getIntent().getSerializableExtra("imageList");
        uriList = (ArrayList<String>)getIntent().getStringArrayListExtra("uriList");

        System.out.println(imageList);
        System.out.println(uriList);

        for (int i = 0; i < uriList.size(); i++) {
            // 추가할 레이아웃
            SubLayout subLayout = new SubLayout(getApplicationContext(), imageList.get(i));
            // 추가될 위치
            LinearLayout layout = (LinearLayout) findViewById(R.id.input_here_layout_2);
            layout.addView(subLayout);
        }
    }
}