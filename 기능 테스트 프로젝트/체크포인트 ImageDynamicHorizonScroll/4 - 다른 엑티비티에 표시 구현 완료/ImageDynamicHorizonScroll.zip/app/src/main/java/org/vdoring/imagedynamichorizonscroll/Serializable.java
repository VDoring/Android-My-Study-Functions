package org.vdoring.imagedynamichorizonscroll;

public class Serializable implements java.io.Serializable {
    String imageUrl;

    Serializable(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
