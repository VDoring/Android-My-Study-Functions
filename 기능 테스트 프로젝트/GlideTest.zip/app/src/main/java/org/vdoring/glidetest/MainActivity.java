// https://blog.yena.io/studynote/2020/06/10/Android-Glide.html
package org.vdoring.glidetest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.signature.ObjectKey;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_IMAGE_FIND_CODE = 0;
    private static final int REQUEST_IMAGE_SIZE_SET_FIND_CODE = 1;

    EditText len_width;
    EditText len_height;
    String image_width_str;
    String image_height_str;
    int image_width = 100;
    int image_height = 100;

    TextView image_width_num;
    TextView image_height_num;
    String width_num;
    String height_num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        len_width = (EditText) findViewById(R.id.len_width);
        len_height = (EditText) findViewById(R.id.len_height);

        findViewById(R.id.btn_imagefind).setOnClickListener(new View.OnClickListener() {  // 사진 선택 버튼 클릭시
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent();
                intent1.setType("image/*");
                intent1.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent1, REQUEST_IMAGE_FIND_CODE);
            }
        });

        findViewById(R.id.btn_imagefind_sizeset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent();
                intent2.setType("image/*");
                intent2.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent2, REQUEST_IMAGE_SIZE_SET_FIND_CODE);
            }
        });

        len_width.setOnClickListener(new View.OnClickListener() {  // 1번째 칸(사진 가로사이즈) 입력창 클릭시
            @Override
            public void onClick(View view) {
                try {
                    image_width_str = len_width.getText().toString();
                    image_width = Integer.parseInt(image_width_str);  // 이미지 가로크기 설정
                } catch (Exception e) {

                }

                image_width_num = findViewById(R.id.num_width);
                width_num = Integer.toString(image_width);
                image_width_num.setText(width_num);
            }
        });

        len_height.setOnClickListener(new View.OnClickListener() {  // 2번째 칸(사진 세로사이즈) 입력창 클릭시
            @Override
            public void onClick(View view) {
                try {
                    image_height_str = len_height.getText().toString();
                    image_height = Integer.parseInt(image_height_str);  // 이미지 세로크기 설정
                } catch (Exception e) {

                }

                image_height_num = findViewById(R.id.num_height);
                height_num = Integer.toString(image_height);
                image_height_num.setText(height_num);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_IMAGE_FIND_CODE && resultCode == RESULT_OK) {
            try {
                Uri uri = data.getData();
                ImageView view_image1 = findViewById(R.id.view_image);

//                RequestOptions requestOptions1 = new RequestOptions();
//                requestOptions1.diskCacheStrategy(DiskCacheStrategy.NONE);
//                requestOptions1.skipMemoryCache(false);
//                requestOptions1.centerCrop();  // 사진 중앙 맞춤
//                requestOptions1.circleCrop();  // 사진 동그란 모양으로 자름
                Glide.with(this)
                        .load(uri)
//                        .apply(requestOptions1)
                        .placeholder(R.drawable.image_placeholder)  // 이미지 로딩할동안 보여줄 이미지 설정
                        .error(R.drawable.image_error)  // 이미지 불러올때 에러 발생시에 대한 이미지 설정
                        .fallback(R.drawable.image_fallback)  // 이미지 uri가 null일경우에 대한 이미지 설정
                        .skipMemoryCache(true)  // 메모리 캐싱 여부. true->캐싱 안함
                        .diskCacheStrategy(DiskCacheStrategy.NONE)  // 디스크 캐싱 여부. NONE->캐싱 안함
                        .into(view_image1);
            } catch(Exception e) {

            }
        }
        else if(requestCode == REQUEST_IMAGE_SIZE_SET_FIND_CODE && resultCode == RESULT_OK) {
            try {
                Uri uri = data.getData();
                ImageView view_image1 = findViewById(R.id.view_image);

//                RequestOptions requestOptions2 = new RequestOptions();
//                requestOptions2.diskCacheStrategy(DiskCacheStrategy.NONE);
//                requestOptions2.skipMemoryCache(false);
//                requestOptions2.centerCrop();  // 사진 중앙 맞춤
//                requestOptions2.circleCrop();  // 사진 동그란 모양으로 자름
                Glide.with(this)
                        .load(uri)
                        .override(image_width, image_height)  // 이미지 크기 조정(숫자가 작은 쪽 기준으로 크기가 비례적으로 조절됨)
//                        .apply(requestOptions2)
                        .placeholder(R.drawable.image_placeholder)  // 이미지 로딩할동안 보여줄 이미지 설정
                        .error(R.drawable.image_error)  // 이미지 불러올때 에러 발생시에 대한 이미지 설정
                        .fallback(R.drawable.image_fallback)  // 이미지 uri가 null일경우에 대한 이미지 설정
                        .skipMemoryCache(true)  // 메모리 캐싱 여부. true->캐싱 안함
                        .diskCacheStrategy(DiskCacheStrategy.NONE)  // 디스크 캐싱 여부. NONE->캐싱 안함
                        .into(view_image1);
            } catch(Exception e) {

            }
        }
    }
}