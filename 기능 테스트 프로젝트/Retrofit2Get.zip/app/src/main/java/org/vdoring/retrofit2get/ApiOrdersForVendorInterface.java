package org.vdoring.retrofit2get;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiOrdersForVendorInterface {
    @GET("orders/for-vendor/{vendor_id}")

    //개체를 가져올때 사용되는 것
    //Call<PostResult> getPosts(@Path("post") String post);  수환이형 예시
    //Call<ApiOrdersForVendor> getData(@Path("vendor_id") String vendor_id);  내가 만든 것

    //배열을 가져올때 사용되는 것
    Call<List<ApiOrdersForVendor>> getData(@Path("vendor_id") String vendor_id);
}
