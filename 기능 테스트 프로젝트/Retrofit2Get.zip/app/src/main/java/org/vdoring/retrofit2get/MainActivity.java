package org.vdoring.retrofit2get;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    TextView getPrint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getPrint = findViewById(R.id.getPrint);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("")  // 바뀌지 않는 주소 넣기(BaseURL)
                .addConverterFactory(GsonConverterFactory.create())  // Gson 변환기 등록
                .build();

        ApiOrdersForVendorInterface service1 = retrofit.create(ApiOrdersForVendorInterface.class);  // 인터페이스 설정

        Call<List<ApiOrdersForVendor>> call = service1.getData("2");  // 파라미터에 값 넣기

        call.enqueue(new Callback<List<ApiOrdersForVendor>>() {
            @Override
            public void onResponse(Call<List<ApiOrdersForVendor>> call, Response<List<ApiOrdersForVendor>> response) {
                if(response.isSuccessful()) {  // 통신 성공시
                    List<ApiOrdersForVendor> res = response.body();
                    getPrint.setText(res.toString());
                }
                else {  // 통신 실패(3xx, 4xx http error)
                    getPrint.setText("실패하였습니다");
                }
            }

            @Override
            public void onFailure(Call<List<ApiOrdersForVendor>> call, Throwable t) {
                //통신 실패(인터넷 끊김, 예외 발생등 시스템적인 이유)
                getPrint.setText("오류로 실패였습니다: "+t.getMessage());
            }
        });

    }
}