package org.vdoring.retrofit2get;

import com.google.gson.annotations.SerializedName;

public class ApiOrdersForVendor {

    @SerializedName("order_number")
    private String order_number;

    @SerializedName("order_date")
    private String order_date;

    @SerializedName("supplier")
    private String supplier;

    @SerializedName("receiver")
    private String receiver;

    @SerializedName("distributer")
    private String distributer;

    @SerializedName("items_info_summary")
    private String items_info_summary;

    @SerializedName("transact_status")
    private String transact_status;

    @SerializedName("vendor_id")
    private String vendor_id;

    @SerializedName("signature_file")
    private String signature_file;

    @SerializedName("closed")
    private String closed;

    // toString()을 Override 해주지 않으면 객체 주소값을 출력함
    @Override
    public String toString() {
        return "PostResult{" +
                "order_number=" + order_number +
                ", order_date=" + order_date +
                ", supplier='" + supplier +
                ", receiver='" + receiver +
                ", distributer=" + distributer +
                ", items_info_summary='" + items_info_summary +
                ", transact_status='" + transact_status +
                ", vendor_id='" + vendor_id +
                ", signature_file='" + signature_file +
                ", closed='" + closed +
                '}';
    }
}
