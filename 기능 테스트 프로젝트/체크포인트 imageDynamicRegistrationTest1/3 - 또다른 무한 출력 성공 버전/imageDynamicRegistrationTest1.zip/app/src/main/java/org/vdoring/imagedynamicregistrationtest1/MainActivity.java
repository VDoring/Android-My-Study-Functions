package org.vdoring.imagedynamicregistrationtest1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {
    int REQUEST_CODE = 1;

    Uri uri;
    LinearLayout linear_layout_vertical;
    LinearLayout linear_layout_horizontal;
    Button btn_image_add;

    int image_count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linear_layout_vertical = findViewById(R.id.linear_layout_vertical);
        linear_layout_horizontal = findViewById(R.id.linear_layout_horizontal);
        btn_image_add = findViewById(R.id.btn_image_add);

        btn_image_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userImageSelect();  // 1. 사용자가 사진 불러오기.
            }
        });
    }

    private void userImageSelect() {
        Intent intentPicture = new Intent();
        intentPicture.setType("image/*");
        intentPicture.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(intentPicture, REQUEST_CODE);
    }

    // https://featherwing.tistory.com/41
    public static int ConvertDPtoPX(Context context, int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {

            if(image_count < 2) {  // 가장 위쪽 사진 2개
                ImageView imageView1 = new ImageView(this);
                LinearLayout.LayoutParams Params1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ConvertDPtoPX(this, 130));
                Params1.weight = 1f;
                imageView1.setLayoutParams(Params1);
                linear_layout_horizontal.addView(imageView1);

                try {
                    uri = data.getData();
                    Glide.with(this)
                            .load(uri)
                            .into(imageView1);
                } catch(Exception e) {
                    System.out.println("1사진 ERROR");
                }

                image_count++;
                System.out.println("1작동");
            }
            else {  // 이후 사진 2개씩 나열 목표
                // 새로운 레이아웃을 어떻게 만들지?
//                LinearLayout newLinearLayout = new LinearLayout(this);
//                newLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
//                newLinearLayout.addView(imageView2);

                ImageView imageView2 = new ImageView(this);
                LinearLayout.LayoutParams Params2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ConvertDPtoPX(this, 130));
                Params2.weight = 1f;
                imageView2.setLayoutParams(Params2);

                linear_layout_vertical.addView(imageView2);  // 사진이 세로로 1개씩 출력이 된다.

                try {
                    uri = data.getData();
                    Glide.with(this)
                            .load(uri)
                            .into(imageView2);
                } catch(Exception e) {
                    System.out.println("2사진 ERROR");
                }

                //setContentView(newLinearLayout);

                image_count++;
                System.out.println("2작동");
            }
        }
    }
}