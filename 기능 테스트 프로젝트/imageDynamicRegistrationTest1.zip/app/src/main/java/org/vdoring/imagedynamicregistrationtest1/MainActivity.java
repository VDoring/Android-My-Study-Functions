package org.vdoring.imagedynamicregistrationtest1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {
    int REQUEST_CODE = 1;

    Uri uri;
    LinearLayout linear_layout;
    Button btn_image_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linear_layout = findViewById(R.id.linear_layout);
        btn_image_add = findViewById(R.id.btn_image_add);

        btn_image_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userImageSelect();  // 1. 사용자가 사진 불러오기.
            }
        });
    }

    private void userImageSelect() {
        Intent intentPicture = new Intent();
        intentPicture.setType("image/*");
        intentPicture.setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(intentPicture, REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            linear_layout.addView(imageView);

            try {
                uri = data.getData();
                Glide.with(this)
                        .load(uri)
                        .into(imageView);
            } catch(Exception e) {

            }
        }
    }
}